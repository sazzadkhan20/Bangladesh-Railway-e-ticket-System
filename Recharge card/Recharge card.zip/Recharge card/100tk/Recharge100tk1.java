//package Class;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Recharge100tk1 extends JFrame //implements ActionListener
{
	JLabel rc50;
	JPanel p1;
	ImageIcon icon1;

	
	public Recharge100tk1()
	{
		super(" Bangladesh Railway Recharge Card ");
		this.setSize(708,407);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setLayout(null);
		icon1 = new ImageIcon(getClass().getResource("intercityTrain.png")); 
        this.setIconImage(icon1.getImage()); 
		
		p1 = new JPanel();
		p1.setBounds(0,0,708,407);
		this.setLocationRelativeTo(null);
		p1.setLayout(null);
		
	//Logo
        ImageIcon icon = new ImageIcon("100.png");
	    rc50 = new JLabel(icon);
	    rc50.setBounds(0,0,708,369);	
		p1.add(rc50);

		this.add(p1);
        setVisible(true);
	}
	
	public static void main(String [] args)
	{
		 new Recharge100tk1();
	}
}
